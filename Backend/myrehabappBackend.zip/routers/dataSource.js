
 const clientLogin = [
    {clientId:"6620989e5b1d6ce905192d33",client_ID:"CDC035",password:"IZA2020"},
    {clientId:"661e15505b1d6ce90519277b",client_ID:"CDC034",password:"JAT2018"},
    {clientId:"661ce0365b1d6ce905191891",client_ID:"CDC033",password:"ARY2020"},
    {clientId:"6617a6b05e892a77f2014345",client_ID:"CDC032",password:"NOA2020"},
    {clientId:"6614e61f5e892a77f2013e9a",client_ID:"CDC031",password:"JOZ2020"},
    {clientId:"6614baca5e892a77f2013daa",client_ID:"CDC030",password:"DEV2008"},
    {clientId:"660e4b585e892a77f20122e4",client_ID:"CDC021",password:"ATH2021"},
    {clientId:"660e2e1b5e892a77f2012230",client_ID:"CDC020",password:"KHA2021"},
    {clientId:"660d2c965e892a77f20119cb",client_ID:"CDC019",password:"ADI2014"},
    {clientId:"660bca95e4c6133b1fc1008e",client_ID:"CDCO18",password:"EVA2024"},
    {clientId:"660b89566a023f816827ddbd",client_ID:"CDC017",password:"SUN1983"},
    {clientId:"660a83946a023f816827d84d",client_ID:"CDC016",password:"LEK2024"},
    {clientId:"6609f190e4c6133b1fc0e522",client_ID:"CDC015",password:"ZAY2019"},
    {clientId:"6609f15ce4c6133b1fc0e516",client_ID:"CDC014",password:"ASR2017"},
    {clientId:"6609f0eae4c6133b1fc0e508",client_ID:"CDC013",password:"YUS2022"},
    {clientId:"6609f0b5e4c6133b1fc0e4fc",client_ID:"CDC012",password:"ETH2024"},
    {clientId:"66065d1de4c6133b1fc0db1a",client_ID:"CDC011",password:"SHR2022"},
    {clientId:"66065c9ce4c6133b1fc0db09",client_ID:"CDC010",password:"MAH2021"},

]

module.exports = clientLogin



