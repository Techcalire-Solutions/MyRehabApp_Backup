const cloudinary = require('cloudinary').v2;


cloudinary.config({ 
    cloud_name: 'dwyc05tmq', 
    api_key: '887482467599254', 
    api_secret: '_hBicAR0GDiqNzIjyGjEYnbjkE0'
  });

module.exports = cloudinary
  